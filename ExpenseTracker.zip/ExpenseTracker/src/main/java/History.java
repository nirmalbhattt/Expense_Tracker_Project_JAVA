import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.*;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Vector;
public class History extends javax.swing.JFrame {
    
    public History() {
        initComponents();
        this.setSize(700, 400);
        this.setLocationRelativeTo(null);
        getEntries();
        getExpenseEntries();
    }
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        history_table = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        h_table = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTable1.setMinimumSize(new java.awt.Dimension(60, 50));
        jScrollPane1.setViewportView(jTable1);

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 24)); // NOI18N
        jLabel1.setText("History");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(295, 25, -1, -1));

        jPanel1.setBackground(new java.awt.Color(255, 255, 51));
        jPanel1.setPreferredSize(new java.awt.Dimension(100, 80));
        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 700, 80));

        history_table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Source", "Date", "Amount"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        history_table.getTableHeader().setReorderingAllowed(false);
        jScrollPane3.setViewportView(history_table);

        getContentPane().add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 330, 270));

        h_table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Category", "Date", "Description", "Amount"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        h_table.getTableHeader().setReorderingAllowed(false);
        jScrollPane2.setViewportView(h_table);
        if (h_table.getColumnModel().getColumnCount() > 0) {
            h_table.getColumnModel().getColumn(0).setResizable(false);
            h_table.getColumnModel().getColumn(2).setResizable(false);
            h_table.getColumnModel().getColumn(3).setResizable(false);
        }

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 130, 360, 270));

        jLabel2.setBackground(new java.awt.Color(51, 255, 0));
        jLabel2.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 16)); // NOI18N
        jLabel2.setText("Income History");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 90, -1, -1));

        jLabel3.setBackground(new java.awt.Color(51, 255, 0));
        jLabel3.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 16)); // NOI18N
        jLabel3.setText("Expense History");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 80, -1, 40));

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 80, 700, 320));

        pack();
    }// </editor-fold>//GEN-END:initComponents
public void getEntries(){
    try{
         Connection conn = DriverManager.getConnection(
                  "jdbc:mysql://localhost:3306/Expenso"+"?useSSL=false&allowPublicKeyRetrieval=true", "root", "oel#123");
         
         ArrayList<Object[]> entries = new ArrayList<>();
         
             Statement stmIncome = conn.createStatement();
    ResultSet rsIncome = stmIncome.executeQuery("SELECT * FROM income order by date asc");

    javax.swing.table.DefaultTableModel dtm = (javax.swing.table.DefaultTableModel) history_table.getModel();

    // Add income data to the table
    while (rsIncome.next()) {
        String source = rsIncome.getString("source");
        Date h_date = rsIncome.getDate("date");
        int h_amount = rsIncome.getInt("amount");
        Object o[] = {h_date, source, h_amount};
        dtm.addRow(o);
    }
    }catch(Exception ex){
        JOptionPane.showMessageDialog(null, ex);
    }
}


public void getExpenseEntries(){
    try{
         Connection conn = DriverManager.getConnection(
                  "jdbc:mysql://localhost:3306/Expenso"+"?useSSL=false&allowPublicKeyRetrieval=true", "root", "oel#123");
         
         ArrayList<Object[]> expense_entries = new ArrayList<>();
          Statement stmExpense = conn.createStatement();
    ResultSet rsExpense = stmExpense.executeQuery("SELECT * FROM expensedb order by date asc" ); 
    javax.swing.table.DefaultTableModel dtm2 = (javax.swing.table.DefaultTableModel) h_table.getModel();
    
          // Add expense data to the table
    while (rsExpense.next()) {
        String category = rsExpense.getString("category");
        Date h_date = rsExpense.getDate("date");
        int h_amount = rsExpense.getInt("amount");
        String desc=rsExpense.getString("Description");
        Object o[] = {category,h_date,desc, h_amount};
        dtm2.addRow(o);
    }
  
}
    catch(Exception ex){
        JOptionPane.showMessageDialog(null, ex);
    }
}
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(History.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(History.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(History.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(History.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new History().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable h_table;
    private javax.swing.JTable history_table;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables
}
